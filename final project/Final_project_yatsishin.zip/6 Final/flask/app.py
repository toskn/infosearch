from flask import Flask, request, render_template
import pandas as pd
import numpy as np

import string  # для .punctuatuion

from razdel import tokenize
from pymorphy2 import MorphAnalyzer
from nltk.corpus import stopwords

import pickle


stops = stopwords.words("russian")

morph = MorphAnalyzer()
stop = set(stopwords.words('russian'))


app = Flask(__name__)


def tfidf_search(query_vec, tfidf_matrix, df):
    res = np.dot(tfidf_matrix, query_vec.T)
    ind = np.argmax(res)
    return df.text[ind]


# препроцессинг
def prep(unprep):
    unprep = str(unprep)
    unprep = unprep.lower()
    unprep = unprep.replace('\n', ' ')
    unprep = unprep.translate(str.maketrans('', '', string.punctuation))
    unprep_tokenized = list(tokenize(unprep))
    lemmas = [morph.parse(i.text)[0].normal_form for i in unprep_tokenized]
    words = [i for i in lemmas if i not in stop]
    return ' '.join(words)


def search(query, search_method):
    # запрос обработали
    query = prep(query)

    # таблицу подгрузили
    df = pd.read_pickle('train_data.pkl')

    if search_method == 'TF-IDF':
        # матрицу подгрузили
        tfidf_matrix = np.load('tfidf_matrix.npy')
        # векторайзер подгрузили
        with open('tfidf_vectorizer.mod', 'rb') as v:
            vectorizer = pickle.load(v)

        query_vec = vectorizer.transform([query]).toarray()
        search_result = tfidf_search(query_vec, tfidf_matrix, df)

    return search_result


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/result')
def searching():
    if request.args['query']:
        query = request.args['query']
        search_method = request.args['search_method']
        answer = search(query, search_method=search_method)
        return render_template('result.html', question=query, answer=answer)
    return render_template('result.html', answer='ошибка')


if __name__ == '__main__':
    app.run(debug=True)

