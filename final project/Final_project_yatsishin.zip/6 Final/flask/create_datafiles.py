import pandas as pd
import numpy as np

import string  # для .punctuatuion
import math  # bm25
from collections import OrderedDict  # для сортировки
from collections import Counter  # для матрицы бм25

from razdel import tokenize
from pymorphy2 import MorphAnalyzer
from nltk.corpus import stopwords

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
import pickle

stops = stopwords.words("russian")

morph = MorphAnalyzer()
stop = set(stopwords.words('russian'))


# препроцессинг
def prep(unprep):
    unprep = str(unprep)
    unprep = unprep.lower()
    unprep = unprep.replace('\n', ' ')
    unprep = unprep.translate(str.maketrans('', '', string.punctuation))
    unprep_tokenized = list(tokenize(unprep))
    lemmas = [morph.parse(i.text)[0].normal_form for i in unprep_tokenized]
    words = [i for i in lemmas if i not in stop]
    return ' '.join(words)


# нужно собрать в датафрейм и сохранить его все обработанные трейны
def create_data_table():
    answers_df = pd.read_excel("answers_base.xlsx")
    questions_df = pd.read_excel("queries_base.xlsx")
    answers_df.rename(columns={'Номер связки': 'connection',
                               'Текст вопросов': 'text'}, inplace=True)
    questions_df.rename(columns={'Номер связки\n': 'connection',
                                 'Текст вопроса': 'text'}, inplace=True)
    qa_df = pd.concat([answers_df, questions_df])
    qa_df = qa_df.drop(columns=['Unnamed: 3', 'Unnamed: 4'])

    corpus = []
    for question in qa_df['text']:
        corpus.append(prep(question))
    for question in qa_df['text']:
        question = prep(question)
    # сохранил таблицу данных с препроцессингом
    qa_df.to_csv('train_data.pkl', index=False)

    # сохранил векторайзер tf-idf
    tfidf_vectorizer = TfidfVectorizer()
    with open('tfidf_vectorizer.mod', 'wb') as v:
        pickle.dump(tfidf_vectorizer, v)

    # сохранил матрицу tf-idf
    tfidf_matrix = tfidf_vectorizer.fit_transform(corpus).toarray()
    np.save('tfidf_matrix', tfidf_matrix)


if __name__ == '__main__':
    create_data_table()
